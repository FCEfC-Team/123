document.addEventListener('DOMContentLoaded', () => {
    const skillItems = document.querySelectorAll('.skill-item');
    const projectCards = document.querySelectorAll('.project-card');
    const navLinks = document.querySelectorAll('.nav-link');
    const dailySayingEl = document.getElementById('daily-saying');

    // 技能项目动态效果
    skillItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            item.style.transform = 'scale(1.1)';
        });
        item.addEventListener('mouseleave', () => {
            item.style.transform = 'scale(1)';
        });
    });

    // 项目卡片动态效果
    projectCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.boxShadow = '0 15px 30px rgba(0,0,0,0.15)';
        });
        card.addEventListener('mouseleave', () => {
            card.style.boxShadow = 'none';
        });
    });

    // 平滑滚动到锚点
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            // 如果是首页链接，滚动到页面顶部
            if (link.getAttribute('href') === '#') {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
                return;
            }

            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);

            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // 获取每日一言
    async function fetchDailySaying() {
        try {
            const response = await fetch('https://api.nxvav.cn/api/yiyan/?encode=json&charset=utf-8');
            if (!response.ok) {
                throw new Error('网络响应错误');
            }
            const data = await response.json();
            
            dailySayingEl.innerHTML = `
                <span class="quote">"${data.yiyan}"</span>
                <span class="author">— ${data.nick}</span>
            `;
        } catch (error) {
            dailySayingEl.innerHTML = `
                <span class="quote">加载每日一言失败，请稍后再试</span>
            `;
            console.error('获取每日一言时出错:', error);
        }
    }

    // 动态更新当前年份
    const footerYear = document.querySelector('footer p');
    if (footerYear) {
        const currentYear = new Date().getFullYear();
        footerYear.textContent = `© ${currentYear} 程序员个人主页 | 保留所有权利`;
    }

    // 调用获取每日一言的函数
    fetchDailySaying();
});
